package testKeyLogger;

import java.util.ArrayList;

public class SomeResponse {
    //public String text;
    public ArrayList<Integer> list = new ArrayList<>();
}
