package testKeyLogger;

import java.util.ArrayList;

public class SomeRequest {
    //public String text;
    //public int[] tab = {0, 1, 2, 3, 4};
    public ArrayList<Integer> list = new ArrayList<>();

    /*int right = 0;
    int left = 0;
    int top = 0;
    int bottom = 0;
    int space = 0;*/

}
